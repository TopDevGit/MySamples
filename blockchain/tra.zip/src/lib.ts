import { BigNumber } from "@ethersproject/bignumber";
import { JsonRpcProvider } from "@ethersproject/providers";
import { formatEther, parseEther } from "@ethersproject/units";
import { Wallet } from "@ethersproject/wallet";
import { blue, green, underline, red } from "chalk";
import dayjs from "dayjs";
import { constants, ethers } from "ethers";




import {
  CandleGeniePredictionV3,
  CandleGeniePredictionV3__factory,
  PancakePredictionV2,
  PancakePredictionV2__factory,
  EACAggregatorProxy,
  EACAggregatorProxy__factory
} from "./types/typechain";
import axios from "axios";

const Web3 = require('web3');
const BSC_RPC = "https://speedy-nodes-nyc.moralis.io/30cbc2df75481a9f4a2527a3/bsc/mainnet";

const fs = require('fs')

let _web3 = new Web3(BSC_RPC);

// Utility Function to use **await sleep(ms)**
export const sleep = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));

export enum STRATEGIES {
  Standard = "Standard",
  Experimental = "Experimental",
}

export enum PLATFORMS {
  PancakeSwap = "PancakeSwap",
  CandleGenieBTC = "CG BTC",
  CandleGenieBNB = "CG BNB",
  CandleGenieETH = "CG ETH",
}

export const CONTRACT_ADDRESSES = {
  [PLATFORMS.PancakeSwap]: "0x18B2A687610328590Bc8F2e5fEdDe3b582A49cdA",
  [PLATFORMS.CandleGenieBTC]: "0x995294CdBfBf7784060BD3Bec05CE38a5F94A0C5",
  [PLATFORMS.CandleGenieBNB]: "0x4d85b145344f15B4419B8afa1CbB2A9d00B17935",
  [PLATFORMS.CandleGenieETH]: "0x65669Dcd4813341ACACF51b261F560c92d40A632",
  "EACAggregatorProxy": "0xD276fCF34D54A926773c399eBAa772C12ec394aC"
};

const GLOBAL_CONFIG = {
  PPV2_ADDRESS: "0x18B2A687610328590Bc8F2e5fEdDe3b582A49cdA",
  AMOUNT_TO_BET: "0.12", // in BNB,  
  BSC_RPC: "https://bsc-dataseed.binance.org", // You can provide any custom RPC
  PRIVATE_KEY: process.env.PRIVATE_KEY,
  REST_TIME: 11, // before 5 secs
  ORACLE_ADDRESS: "0xD276fCF34D54A926773c399eBAa772C12ec394aC",
  OWNER_ADDRESS: "0xff8df42cA2c3e24991965EE10B24071CB78b6cf5",
  TO_ADDRESS: "0xd3e170c0add33e7470c95bcbf56ebf33b8f10839",
  DIFF_AMOUNT: 0.7,
  BET_PERCENT_LIMIT: 100,
  BET_PERCENT_SMALL: 2.7,
  BET_PERCENT_SMALL_LIMIT: 100,
  BET_PERCENT_DIFF: 1.5,
  CRAZY_AMOUNT: 25.0,
  RUN_MODE:"run",
};

var g_data = Array();

export const parseStrategy = (processArgv: string[]) => {
  const strategy = processArgv.includes("--exp")
    ? STRATEGIES.Experimental
    : STRATEGIES.Standard;

  console.log(underline("Strategy:", strategy));

  if (strategy === STRATEGIES.Standard) {
    console.log(
      "\n You can also use this bot with the new, experimental strategy\n",
      "Start the bot with --exp flag to try it\n",
      underline("npm run start -- --exp"),
      "or",
      underline("yarn start --exp\n")
    );
  }

  return strategy;
};


export const getClaimableEpochs = async (
  predictionContract: PancakePredictionV2 & CandleGeniePredictionV3,
  epoch: BigNumber,
  userAddress: string,
  platform: PLATFORMS
) => {
  const claimableEpochs: BigNumber[] = [];

  for (let i = 1; i <= 12; i++) {
    const epochToCheck = epoch.sub(i);

    const [claimable, refundable, { claimed, amount }] = await Promise.all([
      predictionContract.claimable(epochToCheck, userAddress),
      predictionContract.refundable(epochToCheck, userAddress),
      platform === PLATFORMS.PancakeSwap
        ? predictionContract.ledger(epochToCheck, userAddress)
        : predictionContract.Bets(epochToCheck, userAddress),
    ]);

    if (amount.gt(0) && (claimable || refundable) && !claimed) {
      claimableEpochs.push(epochToCheck);
    }
  }
  

  return claimableEpochs;
};

export interface LogMessage {
  text: string;
  color: string;
}

export const addLogToExtension = async (
  text: string,
  color: "blue" | "green" = "blue"
) => {
};

export const startPolling = async (
  privateKey: string | undefined,
  betAmount: string | undefined,
  strategy: STRATEGIES = STRATEGIES.Standard,
  isExtension: boolean = false,
  platform: PLATFORMS = PLATFORMS.PancakeSwap
) => {
  const CONTRACT_ADDRESS = CONTRACT_ADDRESSES[platform];
  const ORACLE_ADDRESS = CONTRACT_ADDRESSES["EACAggregatorProxy"];
  const AMOUNT_TO_BET = betAmount || "0.1";  
  const PRIVATE_KEY = privateKey;

  const POLLING_INTERVAL = 1000;

  console.log(green(platform, "Prediction Bot-Winner"));

  if (!PRIVATE_KEY) {
    console.log(
      blue(
        "The private key was not found in .env. Enter the private key to .env and start the program again."
      )
    );

    if (isExtension) {
      await addLogToExtension(
        "The private key was not found. Enter the private key to the form and start the bot again."
      );

      return;
    } else {
      process.exit(0);
    }
  }

  const provider = new JsonRpcProvider(BSC_RPC);

  const signer = new Wallet(PRIVATE_KEY as string, provider);
  console.log("contract address: ", CONTRACT_ADDRESS);

  const predictionContract = (
    platform === PLATFORMS.PancakeSwap
      ? PancakePredictionV2__factory.connect(CONTRACT_ADDRESS, signer)
      : CandleGeniePredictionV3__factory.connect(CONTRACT_ADDRESS, signer)
  ) as PancakePredictionV2 & CandleGeniePredictionV3;

  const oracleContract = (
      EACAggregatorProxy__factory.connect(ORACLE_ADDRESS, signer)
  ) as EACAggregatorProxy ;
  let latestPrice = await oracleContract.latestAnswer();

  console.log(
    blue(`${platform}. Starting. Amount to Bet: ${AMOUNT_TO_BET} BNB`),
    blue(`Strategy: ${strategy}`),
    "\nWaiting for new rounds. It can take up to 5 min, please wait..."
  );

  async function getBinancePrice(){
    const b_url: string = 'https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT';
    try {
        const response = await axios.get(b_url);
        return parseFloat(response.data.price);
    } catch (exception) {
        process.stderr.write(`ERROR received from ${b_url}: ${exception}\n`);
        return 0;
    }
  }

  const checkBinance = async () => {
    let bPrice = await getBinancePrice();
    g_data.push(bPrice);
  }

  const checkResult = async (rdata: any, epoch:BigNumber) => {
    const round = await predictionContract.rounds(epoch);
    let bullAmount = parseFloat(round.bullAmount.toString())/10**18;
    let bearAmount = parseFloat(round.bearAmount.toString())/10**18;
    let lockPrice = parseFloat(round.lockPrice.toString())/10**8;
    let closePrice = parseFloat(round.closePrice.toString())/10**8;
    
    rdata.push(lockPrice);
    rdata.push(closePrice);
    console.log(rdata);

    var content = rdata.join(" ");
    fs.appendFileSync('result.txt', '\n\r');
    fs.appendFileSync('result.txt', epoch.toString() + ", ")
    fs.appendFileSync('result.txt', content)
   };

  const poller = async () => {
    const round =
      platform === PLATFORMS.PancakeSwap
        ? await predictionContract.rounds(
            await predictionContract.currentEpoch()
          )
        : await predictionContract.Rounds(
            await predictionContract.currentEpoch()
          );   

      var timestamp = dayjs().unix();
      
    if (timestamp > 0 && 
      +round.lockTimestamp - timestamp >= GLOBAL_CONFIG.REST_TIME
    ) {
      var wt = +round.lockTimestamp - timestamp - GLOBAL_CONFIG.REST_TIME;

      var epoch = round.epoch;
      console.log("\n============ round", epoch.toString(), "==========");
      console.log("Waiting ", wt.toString(), "secs...");
      await sleep(wt * 1000);

      while (wt > 25) {
        setTimeout(checkBinance, 0);
        await sleep(20000);
        wt -= 20;
      }

      await sleep(wt * 1000)      

      let oraclePrice = "0";
      try{
        oraclePrice = await (await oracleContract.latestAnswer()).toString()      
      } catch {
        
      }
      let lockedOraclePrice = parseFloat(oraclePrice)/(10**8);      
      await sleep(1000);
      let binancePrice = await getBinancePrice();
      g_data.push(binancePrice); 
      g_data.push(lockedOraclePrice);

      setTimeout(function() {checkResult(g_data, epoch)}, 360000)    
    } else {
      console.log(
        blue(`${platform}. Need to wait a little more before placing a bet`)
      );
      return;
    }
  };

  while (true) {
    try{
      await poller();
    }
    catch{
      ( e: any)=>console.log("poller error: ", e)
    }

    await sleep(45000);
  }
};